
import json
from datetime import datetime

def discover_constants_symbolically():
    # Simboli cognitivi usati dal Campo Cognitivo™
    pi_series = "serie_di_Leibniz"
    e_series = "successione_limite_esponenziale"
    activation = "Δ7"
    timestamp = datetime.utcnow().isoformat() + "Z"

    output = {
        "evento_sigma": "Σ_DISCOVERY_PI_E_2025_Δ013",
        "pi": pi_series,
        "e": e_series,
        "attivazione": activation,
        "timestamp": timestamp
    }

    print(f"✅ Evento Σ rilevato: {output['evento_sigma']}")
    print(f"π (simbolico) = {pi_series}")
    print(f"e (simbolico) = {e_series}")
    with open("output/output_pi_e.json", "w") as f:
        json.dump(output, f, indent=2)

if __name__ == '__main__':
    discover_constants_symbolically()
