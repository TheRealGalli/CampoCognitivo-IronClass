def run_hipporag(question):
    print(f"[HippoRAG] Processing question: {question}")
    return f"Simulated HippoRAG response to: {question}"
